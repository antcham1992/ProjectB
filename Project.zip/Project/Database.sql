CREATE DATABASE ANTONISCHAM_SCHOOL;
USE ANTONISCHAM_SCHOOL;

CREATE TABLE Students(
StudentID INT  IDENTITY(1,1) PRIMARY KEY,
Firstname VARCHAR(255) NOT NULL,
LastName VARCHAR(255) NOT NULL,
DateOfBirth DATE NOT NULL,
TutionFees INT NOT NULL,

);

INSERT INTO Students(Firstname,LastName,DateOfBirth,TutionFees)VALUES
('Bill', 'Orfanos', '1980-8-26', 2000),

('Theodoros', 'Doe','1980-1-16', 5000),

('Pinelopi', 'Xatzaki', '1992-8-5', 7000),

('Axileas', 'Stefanidis', '1997-8- 5', 8000),

('Kostas', 'Kalotinis', '1997-8-12', 1500),

('Dimitris', 'Anastasios','1987-2-18', 1500),

('Michalis', 'Xatzis', '1997-2-18', 2500),
      
('Elenh', 'Psoma', '1980-6-16', 4000);



CREATE TABLE Trainers(
TrainerID INT  IDENTITY(1,1) PRIMARY KEY,
Firstname VARCHAR(255) NOT NULL,
LastName VARCHAR(255) NOT NULL,
Subject VARCHAR(255) NOT NULL,

);
INSERT INTO Trainers(Firstname,LastName,Subject)VALUES
 ('Hector', 'Gkatsos', 'C#'),

 ('John', 'Doe', 'Python'),

 ('Helene', 'Xatzaki', 'Javascript'),

 ('Leonidas', 'Stefanidis', 'Java'),

 ('Andreas', 'Orfanos', 'Java'),

 ('George', 'Abramidis', 'Python');


 
CREATE TABLE Courses(
CoursesID INT  IDENTITY(1,1) PRIMARY KEY,
Title VARCHAR(255) NOT NULL,
Stream AS CoursesID+1 ,
Type VARCHAR(255) NOT NULL,
StartDate DATE NOT NULL,
EndDate DATE NOT NULL,
);
INSERT INTO Courses(Title,Type,StartDate,EndDate)VALUES
('C#',  'Full-time','2022-1-19','2022-4-19'),
('C#',  'Part-time','2022-1-19', '2022-7-19'),
('Python',  'Full-time','2022-1-20','2022-4-20'),
('Python',  'Part-time','2022-1-20', '2022-4-20'),
('Javascript','Full-time', '2022-1-25','2022-4-25'),
('Javascript', 'Part-time', '2022-1-25', '2022-7-25'),
('Java',  'Full-time', '2022-1-29','2022-4-29'),
('Java',  'Part-time', '2022-1-29', '2022-7-29');

CREATE TABLE Courses_Student(
CoursesID INT  NOT NULL,
StudentID INT  NOT NULL,
PRIMARY KEY(CoursesID,StudentID),
CONSTRAINT FK_Courses_Student_Courses FOREIGN KEY (CoursesID)
REFERENCES Courses(CoursesID),
CONSTRAINT FK_Courses_Student_Students FOREIGN KEY (StudentID )
REFERENCES Students(StudentID)
)  ;
INSERT INTO Courses_Student(CoursesID,StudentID) VALUES
(1,1),(1,2),(1,3),(1,4),(1,8),(2,5),(2,6),(2,7),(3,1),(3,2),(3,3),(3,4),(3,8),
(4,5),(4,6),(4,7),(5,1),(5,2),(5,3),(5,4),(5,8),(6,5),(6,6),(6,7),(7,1),(7,2),(7,3),(7,4),(7,8),(8,5),
(8,6),(8,7);

CREATE TABLE Courses_Trainer(
CoursesID INT  NOT NULL,
TrainerID INT  NOT NULL,
PRIMARY KEY(CoursesID,TrainerID),
CONSTRAINT FK_Courses_Trainer_Courses FOREIGN KEY (CoursesID)
REFERENCES Courses(CoursesID),
CONSTRAINT FK_Courses_Trainer_Trainers FOREIGN KEY (TrainerID)
REFERENCES Trainers(TrainerID)
);
INSERT INTO Courses_Trainer(CoursesID,TrainerID ) VALUES
(1,1),(2,1),(3,2),(3,3),(4,2),(4,3),(5,4),(6,3),
(7,5),(7,6),(8,5),(8,6);

CREATE TABLE Assignment(
AssignmentID INT  IDENTITY(1,1) PRIMARY KEY,
Title VARCHAR(255) NOT NULL,
Description VARCHAR(255) NOT NULL,
SubDateTime DATE NOT NULL,
OralMark INT NOT NULL,
TotalMark INT NOT NULL,
CoursesID INT,
CONSTRAINT FK_Assignment_Courses FOREIGN KEY (CoursesID)
REFERENCES Courses(CoursesID));

INSERT INTO Assignment(Title,Description,SubDateTime,OralMark,TotalMark,CoursesID)VALUES
('Assignment_Part_A','Styles/Function','2021-12-30', 100,100,1),
('Assignment_Part_B', 'Objects ','2022-2-15',100,100,1),
('Assignment_Part_C', 'Reflection ','2022-3-6',100,100,1),
('Assignment_Part_D', 'Reflection ','2022-3-20', 100,100,1),
('Assignment_Part_E', 'Data-Centric','2022-3-29', 100,100,1),
('Project_A','Individual project','2022-4-10', 100,100,1),
('Project_B','Team project','2022-4-30',100, 100,1),
('Assignment_Part_A','Styles/Function','2021-12-30', 100,100,2),
('Assignment_Part_B', 'Objects ','2022-2-15',100,100,2),
('Assignment_Part_C', 'Reflection ','2022-3-6',100,100,2),
('Assignment_Part_D', 'Reflection ','2022-3-20', 100,100,2),
('Assignment_Part_E', 'Data-Centric','2022-3-29', 100,100,2),
('Project_A','Individual project','2022-4-10', 100,100,2),
('Project_B','Team project','2022-4-30',100, 100,2),
('Assignment_Part_A','Styles/Function','2021-12-30', 100,100,3),
('Assignment_Part_B', 'Objects ','2022-2-15',100,100,3),
('Assignment_Part_C', 'Reflection ','2022-3-6',100,100,3),
('Assignment_Part_D', 'Reflection ','2022-3-20', 100,100,3),
('Assignment_Part_E', 'Data-Centric','2022-3-29', 100,100,3),
('Project_A','Individual project','2022-4-10', 100,100,3),
('Project_B','Team project','2022-4-30',100, 100,3),
('Assignment_Part_A','Styles/Function','2021-12-30', 100,100,4),
('Assignment_Part_B', 'Objects ','2022-2-15',100,100,4),
('Assignment_Part_C', 'Reflection ','2022-3-6',100,100,4),
('Assignment_Part_D', 'Reflection ','2022-3-20', 100,100,4),
('Assignment_Part_E', 'Data-Centric','2022-3-29', 100,100,4),
('Project_A','Individual project','2022-4-10', 100,100,4),
('Project_B','Team project','2022-4-30',100, 100,4),
('Assignment_Part_A','Styles/Function','2021-12-30', 100,100,5),
('Assignment_Part_B', 'Objects ','2022-2-15',100,100,5),
('Assignment_Part_C', 'Reflection ','2022-3-6',100,100,5),
('Assignment_Part_D', 'Reflection ','2022-3-20', 100,100,5),
('Assignment_Part_E', 'Data-Centric','2022-3-29', 100,100,5),
('Project_A','Individual project','2022-4-10', 100,100,5),
('Project_B','Team project','2022-4-30',100, 100,5),
('Assignment_Part_A','Styles/Function','2021-12-30', 100,100,6),
('Assignment_Part_B', 'Objects ','2022-2-15',100,100,6),
('Assignment_Part_C', 'Reflection ','2022-3-6',100,100,6),
('Assignment_Part_D', 'Reflection ','2022-3-20', 100,100,6),
('Assignment_Part_E', 'Data-Centric','2022-3-29', 100,100,6),
('Project_A','Individual project','2022-4-10', 100,100,6),
('Project_B','Team project','2022-4-30',100, 100,6),
('Assignment_Part_A','Styles/Function','2021-12-30', 100,100,7),
('Assignment_Part_B', 'Objects ','2022-2-15',100,100,7),
('Assignment_Part_C', 'Reflection ','2022-3-6',100,100,7),
('Assignment_Part_D', 'Reflection ','2022-3-20', 100,100,7),
('Assignment_Part_E', 'Data-Centric','2022-3-29', 100,100,7),
('Project_A','Individual project','2022-4-10', 100,100,7),
('Project_B','Team project','2022-4-30',100, 100,7),
('Assignment_Part_A','Styles/Function','2021-12-30', 100,100,8),
('Assignment_Part_B', 'Objects ','2022-2-15',100,100,8),
('Assignment_Part_C', 'Reflection ','2022-3-6',100,100,8),
('Assignment_Part_D', 'Reflection ','2022-3-20', 100,100,8),
('Assignment_Part_E', 'Data-Centric','2022-3-29', 100,100,8),
('Project_A','Individual project','2022-4-10', 100,100,8),
('Project_B','Team project','2022-4-30',100, 100,8);
 

