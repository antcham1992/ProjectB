﻿using ConsoleApp15;
using ConsoleApp15.Controller;
using System;

namespace Final.Application
{
    class TrainerApp
    {
        public static void Trainer()
        {
            Console.Clear();
                TrainerController trainer = new TrainerController();

                string input = "";
                
                do
                {
                TrainerMenu.Menu();
                input = Console.ReadLine();
                    Console.Clear();
                    switch (input)
                    {
                        case "1": trainer.ShowTrainer(); break;
                        case "2": trainer.CreateTrainer(); break;
                    case "3": trainer.EditTrainer(); break;
                    case "4": trainer.DeleteTrainer(); break;
                        case "5": App.Run(); break;
                        default: Console.WriteLine("Ξαναδιαλέξτε"); break;
                    }


                } while (input != "5");
            }
        }
    }


