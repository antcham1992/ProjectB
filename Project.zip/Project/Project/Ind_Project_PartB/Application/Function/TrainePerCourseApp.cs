﻿using ConsoleApp15;
using ConsoleApp15.Controller;
using System;

namespace Final.Application
{
    class TrainerCourseApp
    {
        public static void Course()
        {
            Console.Clear();
            TrainerPerCourseController trainer = new TrainerPerCourseController();

                string input = "";
                
                do
                {
                TrainerCourseMenu.Menu();
                input = Console.ReadLine();
                    Console.Clear();
                    switch (input)
                    {
                        case "1": trainer.ShowTrainerPerCourse(); break;
               
                        case "2":trainer.Add(); break;
                        case "3": trainer.DeleteTrainer(); break;
                       
                     case "4": App.Run(); break;
                        default: Console.WriteLine("Ξαναδιαλέξτε"); break;
                    }


                } while (input != "4");
            }
        }
    }


