﻿using ConsoleApp15.Controller;
using Final.Application;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp15
{
    class UserInput
    {
        public static void CheckChoise1(string choiseInput)
        {
           

            switch (choiseInput)
            {
                case "0": CourseApp.Course(); break;
                case "1": TrainerApp.Trainer(); break;
                case "2": StudentApp.Student(); break;
                case "3": AssignmentApp.Assignment(); break;
                case "4": StudentCourseApp.Course(); break;
                case "5": TrainerCourseApp.Course(); break;
                case "6": AssiCourseApp.Course(); break;
                case "7": AssiCourseStuApp.Course(); break;
                case "e": Console.WriteLine("Ευχαριστούμε!"); ; break;
                case "E": Console.WriteLine("Ευχαριστούμε!"); break;
                default: ChoiseAgain(choiseInput);  break;
            }

        }
       
        public static void ChoiseAgain(string choiseInput)
        {
            Console.Clear();
            SecondMenu.SMenu();
            Console.WriteLine("Ξαναδιαλέξτε");
            choiseInput = Console.ReadLine();
            CheckChoise1( choiseInput);
        }
    }
}
