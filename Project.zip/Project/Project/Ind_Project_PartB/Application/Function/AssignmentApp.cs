﻿using ConsoleApp15;
using ConsoleApp15.Controller;
using System;

namespace Final.Application
{
    class AssignmentApp
    {
        public static void Assignment()
        {
            Console.Clear();
            AssignmentController assignment = new AssignmentController();

                string input = "";
                
                do
                {
                AssignmentMenu.Menu();
                input = Console.ReadLine();
                    Console.Clear();
                    switch (input)
                    {
                        case "1":assignment.ShowAssignment(); break;
                        case "2": assignment.CreateAssignment(); break;
                        case "3": assignment.EditAssignment(); break;
                        case "4": assignment.DeleteAssignment(); break;
                        case "5": App.Run(); break;
                        default: Console.WriteLine("Ξαναδιαλέξτε"); break;
                    }


                } while (input != "5");
            }
        }
    }


