﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp15
{
    class App
    {
        public static void Run()

        {

            
            string choiseInput ="";


            do
            {
                Console.Clear();
                if (choiseInput != "e" && choiseInput != "E")
                {
                   
                    Regards.Welcome();
                    SecondMenu.SMenu();
                    choiseInput = Console.ReadLine();
                    UserInput.CheckChoise1(choiseInput);

                }
              

            } while (choiseInput != "e" && choiseInput != "E" );
        }
    }
}
