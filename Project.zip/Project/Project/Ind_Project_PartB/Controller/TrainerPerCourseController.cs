﻿using ConsoleApp15.RepositoryService;
using Ind_Project_PartB;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp15.Controller
{
    class TrainerPerCourseController
    {
        GTrainerPerCourse courses = new GTrainerPerCourse();
        TrainerPerCourseServices trainer = new TrainerPerCourseServices();
        public void ShowTrainerPerCourse()
        {
            var allTrainerspercourse = trainer.GetCourses();
            if (allTrainerspercourse.ToList().Count()==0)
            {
                Console.WriteLine("Δεν υπαρχουνε καθγητές ανα μάθημα");
            }
            else
            {
                Console.Clear();
                GTrainerPerCourse.GetTrainerPerCourse(allTrainerspercourse);
            }

        }


       
        public void Add()
        {
            var courseId = courses.CourseId();
            var trId = courses.TrainerId();
            trainer.Add(courseId, trId);
        }

       
        public void DeleteTrainer()
        {

            var courseId = courses.CourseId();
            var trId = courses.TrainerId();
            trainer.DeleteStudent(courseId, trId);

        }
    }
}
