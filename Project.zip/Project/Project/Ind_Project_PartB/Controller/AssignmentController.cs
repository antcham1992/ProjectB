﻿using ConsoleApp15.RepositoryService;
using Ind_Project_PartB;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp15.Controller
{
   class AssignmentController
    {
        AssignmentServices assignment = new AssignmentServices();
        public  void ShowAssignment()
        {
            var allAssignment = assignment.GetAssignments();
            if (allAssignment.ToList().Count()==0)
            {
                Console.WriteLine("Δεν υπάρχουνε Assignment!");
            }
            else
            {
                Console.Clear();
                GAssignment.GetAssignment(allAssignment);
            }
        }

        public int CheckForId(int id)
        {
           Assignment assi = assignment.GetAssignment(id);
            return assi == null ? 0 : assi.AssignmentID;
        }
        public void CreateAssignment()
        {

            var assi = GAssignment.CreateAssignment();
            
            assignment.Add(assi);

        }
       
        public void EditAssignment()
        {
            var assi = GAssignment.EditAssignment();
            
            assignment.EditRow(assi.AssignmentID,assi);
        }

        public void DeleteAssignment()
        {

            var assi = GAssignment.DeleteAssi();
            assignment.Delete(assi);

        }
    }
}
