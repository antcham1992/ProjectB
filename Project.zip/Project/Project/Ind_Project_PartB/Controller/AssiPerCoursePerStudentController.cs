﻿using ConsoleApp15.RepositoryService;
using Ind_Project_PartB;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp15.Controller
{
    class AssignmentPerCoursePerStudentController
    {
        GAssigmentPerCoursePerStudent courses = new GAssigmentPerCoursePerStudent();
        AssignmentPerCoursePerStudentServices assignm = new AssignmentPerCoursePerStudentServices();
        public  void ShowAssiPerCourse()
        {
           
           
            var allAssignm = assignm.GetCourses();
            if (allAssignm.ToList().Count()==0)
            {
                Console.WriteLine("Δεν υπάρχουνε assignment ανα μαθητή και ανα μάθημα!");
            }

            else
            {
                Console.Clear();
                GAssigmentPerCoursePerStudent.GetAssigmentPerCoursePerStudent(allAssignm);
            }



        }



        //public void EditCourse()
        //{
        //    var courseId = courses.CourseId();
        //    var asId = courses.AssiId();
        //    //  assignm.Edit(courseId, asId);
        //}

        //public void DeleteCourse()
        //{

        //    var courseId = courses.CourseId();
        //    //    assignm.Delete(courseId);

        //}
        //public void DeleteAssi()
        //{

        //    var courseId = courses.CourseId();
        //    var asId = courses.AssiId();
        //    // assignm.DeleteStudent(courseId, asId);

        //}
    }
}
