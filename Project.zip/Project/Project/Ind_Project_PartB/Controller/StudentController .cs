﻿using ConsoleApp15.RepositoryService;
using Ind_Project_PartB;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp15.Controller
{
    class StudentController
    {
        StudentServices students = new StudentServices();
      
        public void ShowStudent()
        {
            var allStudent = students.GetStudents();
            if (allStudent.ToList().Count()==0)
            {
                Console.WriteLine("Δεν υπάρχουνε μαθητές!");
            }
            else
            {
                Console.Clear();
                GStudent.GetStudent(allStudent);
            }
        }
        public int CheckForId(int id)
        {
            Students student = students.GetStudent(id);
            return student == null?0: student.StudentID;
 }

        public void ShowStudentMoreCourse()
        {
            var allstudent = students.StudentHasMoreThanOneCourse();
            if (allstudent.ToList().Count()==0)
            {
                Console.WriteLine("Δεν υπάρχουνε μαθητές με παραπάνω απο ένα μαθήματα!");
            }
            else
            {
                Console.Clear();

                GStudentHasMoreThanOneCourse.GetStudentHasMoreThanOneCourse(allstudent);
            }
        }
        public void CreateStudent()
        {
            
            var student = GStudent.CreateStudent();
            int stu = student.Count;
            students.Add(student);
           
        }
        public void EditStudent()
        {
            var student = GStudent.EditStudent();
            students.Edit(student.StudentID, student);
        }
        public void DeleteStudent()
        {
            
            var student = GStudent.DeleteStudent();
           
            students.Delete(student);

        }
    }
}
