﻿using ConsoleApp15.RepositoryService;
using Ind_Project_PartB;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp15.Controller
{
    class AssiPerCourseController
    {
        GAssigmentPerCourse assi = new GAssigmentPerCourse();
         AssignmentPerCourseServices assignm = new AssignmentPerCourseServices(); 
        public void ShowAssiPerCourse()
        {
            Console.Clear();
            var allAssignm = assignm.GetCourses();
            if (allAssignm.ToList().Count()==0)
            {
                Console.WriteLine("Δεν υπάρχουν assignment ανα μάθημα");
            }
            else
            {
                Console.Clear();
                GAssigmentPerCourse.GetAssigmentPerCourse(allAssignm);
            }

               }


       
        public void Add()
        {
            var courseId = assi.CourseId();
            var asId = assi.AssiId();
            assignm.Add(courseId, asId);
        }

      
        public void DeleteAssignment()
        {

            var courseId = assi.CourseId();
            var asId = assi.AssiId();
            assignm.DeleteAssignment( asId, courseId);

        }
    }
}
