﻿using ConsoleApp15.RepositoryService;
using Ind_Project_PartB;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp15.Controller
{
    class StudentPerCourseController
    {
        GStudentPerCourse courses = new GStudentPerCourse();
        StudentPerCourseServices student = new StudentPerCourseServices();
        public void ShowStudentPerCourse()
        {
            var allStudentspercourse = student.GetCourses();
            if (allStudentspercourse.ToList().Count()==0)
            {
                Console.WriteLine("Δεν υπαρχουνε μαθηματα ανα μαθητή");
            }
            else
            {
                Console.Clear();
                GStudentPerCourse.GetStudentPerCourse(allStudentspercourse);
            }

        }


       
        public void Add()
        {
            var courseId = courses.CourseId();
            var stuId = courses.StudentId();
            student.Add(courseId, stuId);
        }

       
        public void DeleteStudent()
        {

            var courseId = courses.CourseId();
            var stuId = courses.StudentId();
            student.DeleteStudentWithCourse(courseId, stuId);

        }
    }
}
