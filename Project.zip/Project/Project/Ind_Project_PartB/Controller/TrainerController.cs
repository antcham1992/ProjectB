﻿using ConsoleApp15.RepositoryService;
using Ind_Project_PartB;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp15.Controller
{
    class TrainerController
    {
        TrainerServices trainers = new TrainerServices();
      
        public void ShowTrainer()
        {
            var allTrainer = trainers.GetTrainers();
            if (allTrainer.ToList().Count()==0)
            {
                Console.WriteLine("Δεν υπάρχουνε καθηγητές!");
            }
            Console.Clear();
            GTrainer.GetTrainer(allTrainer);
        }

        public int CheckForId(int id)
        {
            Trainers trainer  = trainers.GetTrainer(id);
            return trainer == null?0: trainer.TrainerID;

        }
        public void CreateTrainer()
        {
            
            var trainer = GTrainer.CreateTrainer();
            int tr = trainer.Count;
            trainers.Add(trainer);
           
        }
        public void EditTrainer()
        {
            var trainer = GTrainer.EditTrainer();
            trainers.Edit(trainer.TrainerID, trainer);
        }
        public void DeleteTrainer()
        {

            var trainer = GTrainer.DeleteTrainer();
            trainers.Delete(trainer);

        }
    }
}
