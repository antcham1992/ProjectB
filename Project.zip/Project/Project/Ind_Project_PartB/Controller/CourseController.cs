﻿using ConsoleApp15.Helper;
using ConsoleApp15.RepositoryService;
using Ind_Project_PartB;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp15.Controller
{
    class CourseController
    {
        CoursesServices courses = new CoursesServices();
        public void ShowCourse()
        {
            var allCourses = courses.GetCourses();
            if (allCourses.ToList().Count() == 0)
            {
                Console.WriteLine("Δεν υπάρχουνε μαθήματα!");
            }
            else
            {
                Console.Clear();
                GCourses.GetCourses(allCourses);
            }
        }
       
       public int CheckForId(int id)
        {
           Courses course= courses.GetCourse(id);
             return course == null ? 0: course.CoursesID;
}

        public  void CreateCourse()
        {
                      
            var course = GCourses.CreateCourse();
            int number = course.Count;
            courses.Add(course,number);
            
        }
        public void EditCourse()
        {
            
            var course = GCourses.EditCourse();
            
            courses.Edit(course.CoursesID, course);
        }
       
        public void DeleteCourse()
        {
           
             var course = GCourses.DeleteCourse();
            courses.Delete(course);

        }
      
    }
}
