﻿using ConsoleApp15.Controller;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp15.Helper
{
    class CourseHelp
    {
       
        public static int InputNumber(string placeholder)
        {


            Console.WriteLine(placeholder);
            int result;
            string input=Console.ReadLine();

            bool checkResult = int.TryParse(input,out result);
            do
            {

                if (result <= 0||!(checkResult))
                {
                    Check(out result, out input, out checkResult);
                }


            } while (result <= 0 || !(checkResult));
            return result;
        }

        public static void Check(out int result, out string input, out bool checkResult)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("Ο αριθμός πρεπει να ειναι μεγαλύτερος του 0 και οχι κειμενο");
            input = Console.ReadLine();
            checkResult = int.TryParse(input, out result);
            Console.ResetColor();
        }

        public static int InputId(string placeholder)
        {


            Console.WriteLine(placeholder);
            int result;
            string input = Console.ReadLine();

            bool checkResult = int.TryParse(input, out result);
            do
            {

                if (result <= 0 || !(checkResult))
                {
                    Check(out result, out input, out checkResult);
                }


            } while (result <= 0 || !(checkResult));
            return RetuturnExistId(result);

        }

        public static int RetuturnExistId(int result)
        {
            int result1 = CheckId(result);
            if (result1 == 0)
            {
                Console.WriteLine("To μαθημα με id: " + result + " δεν βρεθηκε!");
                result1 = InputId("Ξαναδώστε id");

            }

            return result1;
        }

        public static int CheckId(int id)
        {
            CourseController CourseController = new CourseController();
            var res = CourseController.CheckForId(id);
          
            return res==0 ? 0 : res;
           

        }
        public static string InputText(string placeholder)
        {
            //try catch  & do while
            Console.WriteLine(placeholder);
            string result = Console.ReadLine();
            return result;
        }
       

        public static string InputType(string placeholder)
        {
            //try catch  & do while
            Console.WriteLine(placeholder);
            Menu();
            string Choise = Console.ReadLine();
            string result = "";
           
            switch (Choise)
                
            {
                case "1": result = "Full-Time"; break;
                case "2": result = "Part-Time"; break;
                default: result = InputType("Ξαναδιαλέξτε"); break;

            }
            return result;
        }

        public static DateTime StartDate(string placeholder)
        {
            Console.WriteLine(placeholder);

            string result = Console.ReadLine();
            try
            {
              DateTime  result1 = DateTime.Parse(result);
                return result1;
            }
            catch
            {
                
                return StartDate("Ξαναδώστε ημερομηνία"); 
            }

           

        }

        public static DateTime EndDate(string placeholder)
        {
            Console.WriteLine(placeholder);
            string result = Console.ReadLine();
            try
            {
                DateTime result1 = DateTime.Parse(result);
                return result1;
            }
            catch
            {

                return StartDate("Ξαναδώστε ημερομηνία");
            }

        }

        static void Menu()
        {
            Console.WriteLine("Πατήστε:");
            Console.WriteLine("1-Για Fulltime");
            Console.WriteLine("2-Για Parttime");
        }
    }
}
