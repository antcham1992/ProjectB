﻿using ConsoleApp15.Controller;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp15.Helper
{
    class StudentHelp
    {
        public static int InputNumber(string placeholder)
        {


            Console.WriteLine(placeholder);
            int result;
            string input = Console.ReadLine();

            bool checkResult = int.TryParse(input, out result);
            do
            {

                if (result <= 0 || !(checkResult))
                {
                    Check(out result, out input, out checkResult);
                }


            } while (result <= 0 || !(checkResult));
            return result;
        }
        public static void Check(out int result, out string input, out bool checkResult)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("Ο αριθμός πρεπει να ειναι μεγαλύτερος του 0 και οχι κειμενο");
            input = Console.ReadLine();
            checkResult = int.TryParse(input, out result);
            Console.ResetColor();
        }
        public static int InputId(string placeholder)
        {
            //try catch  & do while
            Console.WriteLine(placeholder);
            int result;
            string input = Console.ReadLine();

            bool checkResult = int.TryParse(input, out result);
            do
            {

                if (result <= 0 || !(checkResult))
                {
                    Check(out result, out input, out checkResult);
                }


            } while (result <= 0 || !(checkResult));
            return RetuturnExistId(result);
        }
        public static int RetuturnExistId(int result)
        {
            int result1 = CheckId(result);
            if (result1 == 0)
            {
                Console.WriteLine("To μαθημα με id: " + result + " δεν βρεθηκε!");
                result1 = InputId("Ξαναδώστε id");

            }

            return result1;
        }

        public static int CheckId(int id)
        {
            StudentController studentController = new StudentController();
            var res = studentController.CheckForId(id);

            return res == 0 ? 0 : res;


        }
        public static string InputFName(string placeholder)
        {
            //try catch  & do while
            Console.WriteLine(placeholder);
            string result = Console.ReadLine();
            return result;
        }
        public static string InputLName(string placeholder)
        {
            //try catch  & do while
            Console.WriteLine(placeholder);
            string result = Console.ReadLine();
            return result;
        }
        public static DateTime DateOfBirthday(string placeholder)
        {
            Console.WriteLine(placeholder);

            string result = Console.ReadLine();
            try
            {
                DateTime result1 = DateTime.Parse(result);
                return result1;
            }
            catch
            {

                return DateOfBirthday("Ξαναδώστε ημερομηνία");
            }
        }
        public static int InputTutionFee(string placeholder)
        {
            //try catch  & do while
            Console.WriteLine(placeholder);


            int result;
            string input = Console.ReadLine();

            bool checkResult = int.TryParse(input, out result);
            do
            {

                if (result <1000 || !(checkResult))
                {
                    Check(out result, out input, out checkResult);
                }


            } while (result < 1000 || !(checkResult));
            return result;
        }

       

        

       
    }
}
