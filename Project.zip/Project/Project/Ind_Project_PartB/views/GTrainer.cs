﻿using ConsoleApp15.Helper;
using System;
using System.Collections.Generic;

namespace Ind_Project_PartB
{
    public class GTrainer
    {

        public static void GetTrainer(List<Trainers> trainers)
        {
            
            Console.WriteLine("----------------------ΚΑΘΗΓΗΤΕΣ----------------------");
            Console.ForegroundColor = ConsoleColor.Yellow;

            Console.WriteLine($"{"Id",-15}{"Ονομα",-15}{"Επίθετο",-15}{"Μάθημα",-15}");
            Console.ResetColor();
            foreach (var trai in trainers)
            {
                Console.WriteLine($"{trai.TrainerID,-15}{trai.Firstname,-15}{trai.LastName,-15}{trai.Subject,-15}");
            }
        }

        public static List<Trainers> CreateTrainer()
        {
            Console.Clear();
            
            int number = TrainerHelp.InputNumber("Δώστε αριθμό καθηγητών");

            List<Trainers> trainerNumber = new List<Trainers>();
            for (int i = 0; i < number; i++)
            {
                Console.WriteLine((i + 1) + "ος -Καθηγητής");
                string firstName = TrainerHelp.InputFName("Δώστε όνομα");
                string lastName = TrainerHelp.InputLName("Δώστε επίθετο");
                string subject = TrainerHelp.Subject("Δώστε Subject");

                Trainers trainer = new Trainers() { Firstname= firstName ,LastName= lastName ,Subject= subject };
                trainerNumber.Add(trainer);

            }
            return trainerNumber;
        }
        public static Trainers EditTrainer()
        {

            int id = TrainerHelp.InputId("Δώστε Id καθηγητή");

            string firstName = TrainerHelp.InputFName("Δώστε όνομα");
            string lastName = TrainerHelp.InputLName("Δώστε επίθετο");
            string subject = TrainerHelp.Subject("Δώστε Subject");
            Trainers trainer = new Trainers () { TrainerID=id,Firstname = firstName, LastName = lastName, Subject = subject };
      
            return trainer;
        }
        public static int DeleteTrainer()
        {
            int trainerId = TrainerHelp.InputId("Δώστε Id καθηγητή");
            return trainerId;
        }
    }
}