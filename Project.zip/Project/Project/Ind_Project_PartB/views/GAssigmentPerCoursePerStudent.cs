﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ind_Project_PartB
{
    public class GAssigmentPerCoursePerStudent
    {
        public static void GetAssigmentPerCoursePerStudent(List<GetAssignmentPerCourcePerStudent> assignments)
        {
            Console.WriteLine("--------------------------ΑSSIGNMENT ΑΝΑ ΜΑΘΗMA ΑΝΑ ΜΑΘΗΤΉ--------------------------");
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine($"{"CourseId",-15}{"'Ονομα",-15}{"Επίθετο",-15}{"Τίτλος",-15}");
            Console.ResetColor();
            ANTONISCHAM_SCHOOLEntities db = new ANTONISCHAM_SCHOOLEntities();
            
            foreach (var assi in assignments)
            {
                Console.WriteLine($"{assi.CoursesID,-15}{assi.Firstname,-15}{assi.LastName,-15}{assi.Title}");
            }
        }
    }
}
