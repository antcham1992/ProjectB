﻿using System;

namespace Final.Application
{
    class CourseMenu
    {
        public static void Menu()
        {
            Console.WriteLine();
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("1 - Για να δείτε τα Mαθήματα ");
            Console.WriteLine("2 - Για να δημιουργηγετε Μαθήματα");
            Console.WriteLine("3 - Για να επεξεργαστείτε");
            Console.WriteLine("4 - Για να διαγράψετε");
            Console.WriteLine("5 - Για να επιστρέψετε στο αρχικό μενού");
            Console.ResetColor();
            Console.WriteLine();
        }
    }
    }


