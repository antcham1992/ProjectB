﻿using System;

namespace Final.Application
{
    class StudentMenu
    {
        public static void Menu()
        {
            Console.WriteLine();
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("1 - Για να δείτε τoυς Mαθητες ");
            Console.WriteLine("2 - Για να δείτε  μαθητές που έχουνε περισσότερα απο ένα μαθήματα");
            Console.WriteLine("3 - Για να δημιουργηγετε Μαθητή");
            Console.WriteLine("4 - Για να επεξεργαστείτε");
            Console.WriteLine("5 - Για να διαγράψετε");
            Console.WriteLine("6 - Για να επιστρέψετε στο αρχικό μενού");
            Console.ResetColor();
            Console.WriteLine();
        }
    }
    }


