﻿using System;

namespace Final.Application
{
    class StudentCourseMenu
    {
        public static void Menu()
        {
            Console.WriteLine();
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("1 - Για να δείτε τα όλους τους μαθητές ανά Mαθήμα ");            
            Console.WriteLine("2 - Για να προσθέσετε μαθητη και στο μαθημα");
            Console.WriteLine("3 - Για να διαγράψετε μαθητή και μάθημα");
            Console.WriteLine("4 - Για να επιστρέψετε στο αρχικό μενού");
            Console.ResetColor();
            Console.WriteLine();
        }
    }
    }


