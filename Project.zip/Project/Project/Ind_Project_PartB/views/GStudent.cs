﻿using ConsoleApp15.Helper;
using System;
using System.Collections.Generic;

namespace Ind_Project_PartB
{
    public class GStudent
    {

        public static void GetStudent(List<Students> student)
        {
           
            Console.WriteLine("-------------------------------ΜΑΘΗΤΕΣ-------------------------------");


            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine($"{"Ιd",-15}{"Ονομα",-15}{"Επίθετο",-15}{"Ημ/νια",-15}{"Δίδακτρα",-15}");
            Console.ResetColor();
            foreach (var stu in student)
            {
                Console.WriteLine($"{stu.StudentID,-15}{stu.Firstname,-15}{stu.LastName,-15}{stu.DateOfBirth,-15:dd/MM/yyyy}{stu.TutionFees,-15}");
            }
        }

        public static List<Students> CreateStudent()
        {

            int StudentNumber = StudentHelp.InputNumber("Δώστε αριθμό μαθητών");
            List<Students> numberStudent = new List<Students>();

            for (int i = 0; i < StudentNumber; i++)
            {
                Console.WriteLine((i + 1) + "oς Μαθητής");
                string firstName = StudentHelp.InputFName("Δώστε όνομα");
                string lastName = StudentHelp.InputLName("Δώστε επίθετο");
                DateTime bitrhdayDate = StudentHelp.DateOfBirthday("Δώστε ημερομηνία γεννησης π.χ.03/05/1980");
                int tutionFees = StudentHelp.InputTutionFee("Δώστε δίδακτρα");

                Students student = new Students() { Firstname= firstName ,LastName= lastName ,DateOfBirth= bitrhdayDate ,TutionFees=tutionFees};
                numberStudent.Add(student);

            }

            return numberStudent;
        }
        public static Students EditStudent()
        {

            int id = StudentHelp.InputId("Δώστε Id μαθητή");
            string firstName = StudentHelp.InputFName("Δώστε όνομα");
            string lastName = StudentHelp.InputLName("Δώστε επίθετο");
            DateTime bitrhdayDate = StudentHelp.DateOfBirthday("Δώστε ημερομηνία γεννησης π.χ.03/05/2022");
            int tutionFees = StudentHelp.InputTutionFee("Δώστε δίδακτρα");

            Students student = new Students()  {StudentID=id, Firstname = firstName, LastName = lastName, DateOfBirth = bitrhdayDate, TutionFees = tutionFees };
            return student;
        }

      
        public static int DeleteStudent()
        {
            int StudentId = StudentHelp.InputId("Δώστε Id μαθητή");
            return StudentId;
        }

       
    }
       
    }
