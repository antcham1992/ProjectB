﻿using ConsoleApp15.Helper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ind_Project_PartB
{
    public class GAssigmentPerCourse
    {
        public static void GetAssigmentPerCourse(List<GetAssignmentPerCourse> assignments)
        {
            
            Console.WriteLine("------------------ΑSSIGNMENT ΑΝΑ ΜΑΘΗMA------------------");
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine($"{"CourseΙD",-15}{"Τιτλος",-15}{"Τύπος",-18}{"Τίτλος",-15}");
            Console.ResetColor();

            foreach (var co in assignments)
            {
                Console.WriteLine($"{co.CoursesID,-15}{co.Title,-15}{co.Type,-15}{co.Assignment,-15}");

            }
        }

        public int CourseId()
        {
            int id = CourseHelp.InputId("Δώστε Id μαθήματος");
            return id;
        }

        public int AssiId()
        {
            int id = StudentHelp.InputId("Δώστε Id assignment");
            return id;
        }
    }
}
