﻿using ConsoleApp15.Helper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ind_Project_PartB
{
    public class GStudentPerCourse
    {
        public static void GetStudentPerCourse(List<GetStudentPerCourse> courses)
        {
           
            Console.WriteLine("----------MΑΘΗΤΕΣ ΑΝΑ ΜΑΘΗMA----------");
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine($"{"CourseID",-15}{"Όνομα",-15}{"Επίθετο",-15}");
            Console.ResetColor();

            foreach (var co in courses)
            {
                Console.WriteLine($"{co.CoursesID,-15}{ co.Firstname,-15}{co.LastName,-15}");


            }
        }

        public int CourseId()
        {
            int id = CourseHelp.InputId("Δώστε Id μαθήματος");
            return id;
        }

        public int StudentId()
        {
            int id = StudentHelp.InputId("Δώστε Id μαθήτη");
            return id;
        }
    }
}
