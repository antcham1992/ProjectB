﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ind_Project_PartB
{
    public class GStudentHasMoreThanOneCourse
    {
        public static void GetStudentHasMoreThanOneCourse(List<StudentHasMoreThanOneCourse>stu)
        {
           
            Console.WriteLine("----MΑΘΗΤΕΣ MΕ ΠΕΡΙΣΣΟΤΕΡΑ ΑΠΟ ΕΝΑ ΜΑΘΗΜΑΤΑ----");
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine($"{"Ονομα",-15}{"Επίθετο",-15}{"Αριθμός μαθημάτων",-15}");
            Console.ResetColor();
            foreach (var item in stu)
            {
                Console.WriteLine($"{item.Firstname,-15}{item.LastName,-15}{item.Courses,-15}");
            }
        }
    }
}
