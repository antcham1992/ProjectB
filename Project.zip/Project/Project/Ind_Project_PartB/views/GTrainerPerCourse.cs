﻿using ConsoleApp15.Helper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ind_Project_PartB
{
    public class GTrainerPerCourse
    {
        public static void GetTrainerPerCourse(List<GetTrainerPerCourse> trainersPerCourse)
        {
           
           
            Console.WriteLine("----------ΚΑΘΗΓΗΤΕΣ ΑΝΑ ΜΑΘΗMA----------");
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine($"{"CourseId",-15}{"Όνομα",-15}{"Επίθετο",-15}");
            Console.ResetColor();

            foreach (var tr in trainersPerCourse)
            {
                Console.WriteLine($"{tr.CoursesID,-15}{tr.Firstname,-15}{tr.LastName,-15}");

            }
        }

        public int CourseId()
        {
            int id = CourseHelp.InputId("Δώστε Id μαθήματος");
            return id;
        }

        public int TrainerId()
        {
            int id = TrainerHelp.InputId("Δώστε Id καθήγητη");
            return id;
        }
    }
}
