﻿using ConsoleApp15.Helper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ind_Project_PartB
{
    public class GAssignment
    {
        public static void GetAssignment(List<Assignment>assignments)
        {
           
            Console.WriteLine("-------------------------------------------------------------Assignments------------------------------------------------------------");
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine($"{"Id",-10}{"Τιτλος",-25}{"Περιγραφή",-40}{"Παράδοση",-25}{"ΟralMark",-25}{"TotalMark",-25}{"CourseID",-15}");
            Console.ResetColor();
            foreach (var item in assignments)
            {
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.WriteLine($"{item.AssignmentID,-10}{item.Title,-25}{item.Description,-40}{item.SubDateTime,-25:dd/MM/yyyy}{item.OralMark,-25}{item.TotalMark,-25}{item.CoursesID,-15}");
            }
            Console.ResetColor();
        }

       

        public static List<Assignment> CreateAssignment()
    {
            int assigmentNumber = AssignmentHelp.InputNumber("Δώστε αριθμό μαθημάτων");
            Assignment assi=new Assignment();
            List<Assignment> assignments = new List<Assignment>();
         

            for (int j = 0; j < assigmentNumber; j++)
            {
                string title = AssignmentHelp.InputTitle("Δώστε Τίτλο Assignment");
                string description = AssignmentHelp.InputDescription("Δώστε περιγραφή");
                DateTime subdateTime = AssignmentHelp.SubDateTime("Δώστε ημερομηνία παράδοσης π.χ.03/05/2022");
                int oralMark = AssignmentHelp.OralMark("Δώστε προφορικό βαθμό");
                int totalMark = AssignmentHelp.TotalMark("Δώστε συνολικό βαθμο");
                int CourseID = CourseHelp.InputId("Δώστε Ιd μαθήματος");
                assi = new Assignment() { Title=title,Description=description,SubDateTime=subdateTime,OralMark=oralMark,TotalMark=totalMark,CoursesID= CourseID };

                assignments.Add(assi);

            }
            return assignments;
        }
       
       
        public static Assignment EditAssignment()
        {

            int id = AssignmentHelp.InputId("Δώστε Id assignment ");
            string title = AssignmentHelp.InputTitle("Δώστε Τίτλο");
            string description = AssignmentHelp.InputDescription("Δώστε περιγραφή");
            DateTime subdateTime = AssignmentHelp.SubDateTime("Δώστε ημερομηνία παράδοσης π.χ.03/05/2022");
            int oralMark = AssignmentHelp.OralMark("Δώστε προφορικό βαθμό");
            int totalMark = AssignmentHelp.TotalMark("Δώστε συνολικό βαθμο");
            int CourseID = CourseHelp.InputId("Δώστε Ιd μαθήματος");
            Assignment assignment = new Assignment() {AssignmentID=id, Title = title, Description = description, SubDateTime = subdateTime, OralMark = oralMark, TotalMark = totalMark, CoursesID = CourseID };

            return assignment;
        }
        public static int DeleteAssi()
        {
            
            int AssiId = AssignmentHelp.InputId("Δώστε Id assignment ");
            return AssiId;
        }
    }
}
