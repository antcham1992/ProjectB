﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp15.Helper
{
    class StudentHelp
    {
        public static int InputNumber(string placeholder)
        {


            Console.WriteLine(placeholder);
            int result = Convert.ToInt32(Console.ReadLine());
            do
            {

                if (result <= 0)
                {
                    Console.WriteLine("Ξαναδώστε αριθμό μεγαλύτερο του 0");
                    result = Convert.ToInt32(Console.ReadLine());
                }


            } while (result <= 0);
            return result;
        }
        public static int InputId(string placeholder)
        {
            //try catch  & do while
            Console.WriteLine(placeholder);
            int result = Convert.ToInt32(Console.ReadLine());
            return result;
        }
        public static string InputFName(string placeholder)
        {
            //try catch  & do while
            Console.WriteLine(placeholder);
            string result = Console.ReadLine();
            return result;
        }
        public static string InputLName(string placeholder)
        {
            //try catch  & do while
            Console.WriteLine(placeholder);
            string result = Console.ReadLine();
            return result;
        }
        public static DateTime DateOfBirthday(string placeholder)
        {
            Console.WriteLine(placeholder);

            string result = Console.ReadLine();
            try
            {
                DateTime result1 = DateTime.Parse(result);
                return result1;
            }
            catch
            {

                return DateOfBirthday("Ξαναδώστε ημερομηνία");
            }
        }
        public static int InputTutionFee(string placeholder)
        {
            //try catch  & do while
            Console.WriteLine(placeholder);
            int result = Convert.ToInt32(Console.ReadLine());
            do
            {

                if (result <=1000)
                {
                    Console.WriteLine("Ξαναδώστε αριθμό μεγαλύτερο του 1000");
                    result = Convert.ToInt32(Console.ReadLine());
                }


            } while (result<1000);
            return result;
        }

       

        

       
    }
}
