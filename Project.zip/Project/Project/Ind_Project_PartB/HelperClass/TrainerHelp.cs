﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp15.Helper
{
    class TrainerHelp
    {
        public static int InputId(string placeholder)
        {
            //try catch  & do while
            Console.WriteLine(placeholder);
            int result = Convert.ToInt32(Console.ReadLine());
            return result;
        }
        public static string InputFName(string placeholder)
        {
            //try catch  & do while
            Console.WriteLine(placeholder);
            string result = Console.ReadLine();
            return result;
        }
        public static string InputLName(string placeholder)
        {
            //try catch  & do while
            Console.WriteLine(placeholder);
            string result = Console.ReadLine();
            return result;
        }
        public static string Subject(string placeholder)
        {
            //try catch  & do while
            Console.WriteLine(placeholder);
            string result = Console.ReadLine();
            return result;
        }






    }
}
