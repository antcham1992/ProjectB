﻿using Ind_Project_PartB;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp15.RepositoryService
{
    class TrainerPerCourseServices
    {
        ANTONISCHAM_SCHOOLEntities db = new ANTONISCHAM_SCHOOLEntities();
        public List<GetTrainerPerCourse> GetCourses() => db.GetTrainerPerCourses.ToList();

     
        public void Add(int coId, int trId)
        {
            var trainer = db.Trainers.ToList().Find(x => x.TrainerID == trId);
            var course = db.Courses.ToList().Find(x => x.CoursesID == coId);

            course.Trainers.Add(trainer);
            db.SaveChanges();
        }

      
        public void DeleteStudent(int coId, int trId)
        {

            db.DeleteTrainer(coId, trId);
            db.SaveChanges();
        }
    }
}
