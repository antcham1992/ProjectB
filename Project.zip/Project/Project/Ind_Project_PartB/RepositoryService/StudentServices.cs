﻿using Ind_Project_PartB;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp15.RepositoryService
{
    class StudentServices
    {
        public ANTONISCHAM_SCHOOLEntities db = new ANTONISCHAM_SCHOOLEntities();
        public List<Students> GetStudents() => db.Students.ToList();

        public Students GetStudent(int id) => db.Students.Find(id);
        public List<StudentHasMoreThanOneCourse> StudentHasMoreThanOneCourse() => db.StudentHasMoreThanOneCourses.ToList();


        public void Add(List<Students> students)
        {
          

            foreach (var student in students)
            {
                db.Entry(student).State = EntityState.Added;
            }

            db.SaveChanges();
        }
        public void Edit(int studentId, Students newStudent)
        {
            var student = db.Students.Find(studentId);

            db.UpdateStudent( student.StudentID= studentId,  student.Firstname= newStudent.Firstname, student.LastName= newStudent.LastName, student.DateOfBirth= newStudent.DateOfBirth, student.TutionFees= newStudent.TutionFees);

            db.SaveChanges();
        }
      
        public void Delete(int studentId)
        {


            
           
            var studentPerCourses = db.GetStudentPerCourses.Where(x=>x.StudentID==studentId);
            List<int> numberOfId = new List<int>();
            foreach (var item in studentPerCourses)
            {

                numberOfId.Add(item.CoursesID);
              
            }

            for (int i = 0; i < numberOfId.Count(); i++)
            {
                db.DeleteStudent(numberOfId[i], studentId);
            }

            var student = db.Students.Find(studentId);

            db.Entry(student).State = EntityState.Deleted;


            
            db.SaveChanges();
        }
        
        

        
    }
}
