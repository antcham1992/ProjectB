﻿using Ind_Project_PartB;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp15.RepositoryService
{
    class AssignmentPerCoursePerStudentServices
    {
      public  ANTONISCHAM_SCHOOLEntities db = new ANTONISCHAM_SCHOOLEntities();
        public List<GetAssignmentPerCourcePerStudent> GetCourses() => db.GetAssignmentPerCourcePerStudents.ToList();

        
          
        

      
    }
}
