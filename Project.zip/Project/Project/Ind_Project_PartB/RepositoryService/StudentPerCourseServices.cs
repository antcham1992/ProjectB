﻿using Ind_Project_PartB;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp15.RepositoryService
{
    class StudentPerCourseServices
    {
        public ANTONISCHAM_SCHOOLEntities db = new ANTONISCHAM_SCHOOLEntities();
        public List<GetStudentPerCourse> GetCourses() => db.GetStudentPerCourses.ToList();
        

        public void Add(int coId,int stuId)
        {
            var student = db.Students.ToList().Find(x => x.StudentID == stuId);
            var course = db.Courses.ToList().Find(x => x.CoursesID == coId);


            course.Students.Add(student);

            db.SaveChanges();
        }

      
        public void DeleteStudentWithCourse(int coId, int stuId)
        {
            db.DeleteStudent(coId, stuId);
            db.SaveChanges();
        }

    }
}
