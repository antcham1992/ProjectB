﻿using Ind_Project_PartB;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp15.RepositoryService
{
    class AssignmentServices
    {
        public ANTONISCHAM_SCHOOLEntities db = new ANTONISCHAM_SCHOOLEntities();

        public Assignment GetAssignment(int id) => db.Assignments.Find(id);
        public List<Assignment> GetAssignments()=> db.Assignments.ToList();
        

        public void Add(List<Assignment> assignments)
        {

            foreach (var assignment in assignments)
            {
                db.Entry(assignment).State = EntityState.Added;
            }

            db.SaveChanges();
           
        }
      
        public void EditRow(int assigmentId,  Assignment newAssigment)
        {

            var assi = db.Assignments.Find(assigmentId);

            db.UpdateAssignment(assi.AssignmentID,assi.Title= newAssigment.Title,assi.Description= newAssigment.Description,assi.SubDateTime= newAssigment.SubDateTime,assi.OralMark= newAssigment.OralMark,assi.TotalMark= newAssigment.TotalMark,assi.CoursesID= newAssigment.CoursesID);

            db.SaveChanges();

        }
        public void Delete(int assigmentId)
        {
            var assignment = db.Assignments.Find(assigmentId);
            db.Entry(assignment).State = EntityState.Deleted;

            db.SaveChanges();
        }

        
    }
}

