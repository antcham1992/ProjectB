﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Entity;
using System.Threading.Tasks;
using ConsoleApp15;
using Ind_Project_PartB;

namespace ConsoleApp15.RepositoryService
{
    class TrainerServices
    {
        public ANTONISCHAM_SCHOOLEntities db = new ANTONISCHAM_SCHOOLEntities();



        public List<Trainers> GetTrainers() => db.Trainers.ToList();

        public Trainers GetTrainer(int id) => db.Trainers.Find(id);

        public void Add(List<Trainers> trainers)
        {

            foreach (var trainer in trainers)
            {
                db.Entry(trainer).State = EntityState.Added;
            }

            db.SaveChanges();

        }
        public void Edit(int trainerId, Trainers newTrainer)
        {

            var trainer = db.Trainers.Find(trainerId);

            db.UpdateTrainer(trainer.TrainerID, trainer.Firstname = newTrainer.Firstname, trainer.LastName = newTrainer.LastName, trainer.Subject = newTrainer.Subject);

            db.SaveChanges();

        }
        public void Delete(int trainerId)
        {
            DeleteRowStudentWithCourse(trainerId);

            var trainer = db.Trainers.Find(trainerId);

            db.Entry(trainer).State = EntityState.Deleted;

            db.SaveChanges();
        }

        private void DeleteRowStudentWithCourse(int trainerId)
        {
            var trainerPerCourses = db.GetTrainerPerCourses.Where(x => x.TrainerID == trainerId);
            List<int> numberOfId = new List<int>();
            foreach (var item in trainerPerCourses)
            {

                numberOfId.Add(item.CoursesID);

            }

            for (int i = 0; i < numberOfId.Count(); i++)
            {
                db.DeleteTrainer(numberOfId[i], trainerId);
            }
        }


    }
    }

