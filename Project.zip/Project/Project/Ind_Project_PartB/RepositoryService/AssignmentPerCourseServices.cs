﻿using Ind_Project_PartB;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;
namespace ConsoleApp15.RepositoryService
{
    class AssignmentPerCourseServices
    {
        public ANTONISCHAM_SCHOOLEntities db = new ANTONISCHAM_SCHOOLEntities();
        public List<GetAssignmentPerCourse> GetCourses()=> db.GetAssignmentPerCourses.ToList();
        

        public void Add(int coId, int asId)
        {
            
            var course = db.Courses.ToList().Find(x => x.CoursesID == coId);
            var assi = db.Assignments.ToList().Find(x => x.AssignmentID == asId);
            
            course.Assignments.Add(assi);
            
            db.SaveChanges();
        }

     
        public void DeleteAssignment(int asId,int coId)
        {

            db.DeleteAssignment(asId, coId);
            db.SaveChanges();

        }
    }
}
