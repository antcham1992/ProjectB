﻿using Ind_Project_PartB;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace ConsoleApp15.RepositoryService
{
    class CoursesServices
    {
        public ANTONISCHAM_SCHOOLEntities db = new ANTONISCHAM_SCHOOLEntities();
        public List<Courses> GetCourses() => db.Courses.ToList();
        public Courses GetCourse(int id)=> db.Courses.Find(id);




        public void Add(List<Courses> courses, int number)

        {
            

            foreach (var course in courses)
            {
                db.Entry(course).State = EntityState.Added;
            }

            db.SaveChanges();

        }
        public void Edit(int CourseId, Courses newCourse)
        {
            var course = db.Courses.Find(CourseId);
            
            db.UpdateCourses(course.CoursesID, course.Title = newCourse.Title, course.Type = newCourse.Type, course.StartDate = newCourse.StartDate, course.EndDate = newCourse.EndDate);

            db.SaveChanges();
        }
        public void DeleteStudentFromCourse(int CourseId)
        {
            var studentPerCourses = db.GetStudentPerCourses.Where(x => x.CoursesID == CourseId);
            List<int> numberOfId = new List<int>();
            foreach (var item in studentPerCourses)
            {

                numberOfId.Add(item.StudentID);

            }

            for (int i = 0; i < numberOfId.Count(); i++)
            {
                db.DeleteStudent(CourseId, numberOfId[i]);
            }

            db.SaveChanges();
        }

        public void DeleteTrainerFromCourse(int CourseId)
        {
            var trainerPerCourses = db.GetTrainerPerCourses.Where(x => x.CoursesID == CourseId);
            List<int> numberOfId = new List<int>();
            foreach (var item in trainerPerCourses)
            {

                numberOfId.Add(item.TrainerID);

            }

            for (int i = 0; i < numberOfId.Count(); i++)
            {
                db.DeleteTrainer(CourseId, numberOfId[i]);
            }

           
            db.SaveChanges();
        }
        public void DeleteAsigmentFromCourse(int CourseId)
        {
            var assiPerCourses = db.Assignments.Where(x => x.CoursesID == CourseId);
            
            foreach (var item in assiPerCourses)
            {

                item.CoursesID = null;
                db.Entry(item).State = EntityState.Modified;
            }

           


            db.SaveChanges();
        }
        public void Delete(int courseId)
        {
           
            DeleteStudentFromCourse(courseId);
            DeleteTrainerFromCourse(courseId);
            DeleteAsigmentFromCourse(courseId);
            var course = db.Courses.Find(courseId);

            db.Entry(course).State = EntityState.Deleted;

            db.SaveChanges();
        }
        
    }
}
