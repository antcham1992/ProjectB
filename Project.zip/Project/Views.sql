USE ANTONISCHAM_SCHOOL;

CREATE VIEW GetStudentPerCourse AS
SELECT c.CoursesID ,c.StudentID,Firstname,LastName FROM Students s
INNER JOIN  Courses_Student c ON c.StudentID=s.StudentID;


CREATE VIEW GetTrainerPerCourse AS
SELECT c.CoursesID ,c.TrainerID,Firstname,LastName FROM Trainers t
INNER JOIN  Courses_Trainer c ON c.TrainerID=t.TrainerID;



CREATE VIEW GetAssignmentPerCourse AS
SELECT c.CoursesID ,c.Title,c.Type, a.AssignmentID,a.Title AS Assignment FROM Assignment a
INNER JOIN  Courses c ON a.CoursesID=c.CoursesID;


CREATE VIEW GetAssignmentPerCourcePerStudent AS
SELECT  DISTINCT c.CoursesID, s.Firstname,s.LastName,a.Title FROM ((students s
INNER JOIN Courses_Student c ON c.StudentID=s.StudentID)
INNER JOIN Assignment a ON a.CoursesID=c.CoursesID);



SELECT*FROM GetAssignmentPerCourcePerStudent;


CREATE VIEW StudentHasMoreThanOneCourse AS
SELECT s.Firstname,s.LastName ,COUNT(*) AS Courses FROM Students s
INNER JOIN  Courses_Student c ON c.StudentID=s.StudentID GROUP BY Firstname ,LastName  HAVING COUNT(*)>1;

