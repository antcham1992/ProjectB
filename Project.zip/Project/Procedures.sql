USE ANTONISCHAM_SCHOOL;

CREATE PROCEDURE UpdateCourses(@Id INT,@Title VARCHAR(255),@Type VARCHAR(255),@startday DATE,@endday DATE) AS
BEGIN
UPDATE Courses SET
Title=@Title,
Type=@Type,
StartDate=@startday,
EndDate=@endday 
 WHERE
CoursesID=@Id ;
END


CREATE PROCEDURE UpdateStudent(@Id INT,@Firstname VARCHAR(255),@LastName VARCHAR(255),@DateOfBirth DATE,@TutionFees INT) AS
BEGIN
UPDATE Students SET
Firstname=@Firstname,
LastName=@LastName,
DateOfBirth=@DateOfBirth,
TutionFees=@TutionFees WHERE
StudentID=@Id ;
END

CREATE PROCEDURE UpdateTrainer(@Id INT,@Firstname VARCHAR(255),@LastName VARCHAR(255),@Subject VARCHAR(255)) AS
BEGIN
UPDATE Trainers SET
Firstname=@Firstname,
LastName=@LastName,
Subject=@Subject
 WHERE
TrainerID=@Id ;
END

CREATE PROCEDURE UpdateAssignment(@Id INT,@Title VARCHAR(255),@Description VARCHAR(255),@subDate DATE,@OralMark INT,@Totalmark INT,@CourseID INT) AS
BEGIN
UPDATE Assignment SET
Title=@Title,
Description=@Description,
SubDateTime=@subDate,
OralMark=@OralMark ,
TotalMark=@Totalmark ,
CoursesID=@CourseID
 WHERE
AssignmentID=@Id ;
END



CREATE PROCEDURE DeleteTrainer (@couId INT ,@traiId INT) AS
BEGIN
DELETE FROM Courses_Trainer WHERE CoursesID=@couId AND TrainerID=@traiId;
END

CREATE PROCEDURE DeleteStudent (@couId INT ,@stuId INT) AS
BEGIN
DELETE FROM Courses_Student WHERE CoursesID=@couId AND StudentID=@stuId;
END


CREATE PROCEDURE DeleteAssignment (@assiId INT,@couId INT ) AS
BEGIN
DELETE FROM Assignment  WHERE AssignmentID=@assiId AND CoursesID=@couId;
END




